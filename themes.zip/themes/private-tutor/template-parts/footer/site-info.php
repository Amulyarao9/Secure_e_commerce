<?php
/**
 * Displays footer site info
 *
 * @subpackage Private Tutor
 * @since 1.0
 * @version 1.4
 */

?>
<div class="site-info">
	<p><?php private_tutor_credit(); ?></p>
</div>